// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "@openzeppelin/contracts/access/Ownable.sol";
import "@openzeppelin/contracts/security/ReentrancyGuard.sol";
import "@openzeppelin/contracts/security/Pausable.sol";
import "@openzeppelin/contracts/utils/Address.sol";
import "@openzeppelin/contracts/utils/cryptography/ECDSA.sol";
import "@openzeppelin/contracts/finance/PaymentSplitter.sol";
import "erc721a/contracts/ERC721A.sol";

contract MintGrindNFT is ERC721A, Ownable, ReentrancyGuard, Pausable, PaymentSplitter {
    using Address for address payable;
    using ECDSA for bytes32;

    // --- Configuration Constants ---
    // IMPORTANT: Set this to the chain ID of the network this contract will be deployed on.
    // E.g., 1 for Ethereum Mainnet, 137 for Polygon Mainnet.
    uint256 private immutable TARGET_CHAIN_ID;

    // --- State Variables ---
    uint256 public mintPrice;
    uint256 public maxSupply;
    uint256 public maxPerWallet;
    address public signer;

    mapping(address => uint256) public minted;
    mapping(address => uint256) public nonces;
    mapping(bytes32 => bool) public usedHashes;

    // --- Events ---
    event Minted(address indexed minter, uint256 quantity);
    event SignerUpdated(address indexed oldSigner, address indexed newSigner);
    event MintPriceUpdated(uint256 oldPrice, uint256 newPrice);
    event MaxSupplyUpdated(uint256 oldSupply, uint256 newSupply);
    event MaxPerWalletUpdated(uint256 oldLimit, uint256 newLimit);
    event PayeeReleased(address indexed payee, uint256 amount);


    constructor(
        string memory name_,
        string memory symbol_,
        uint256 mintPrice_,
        uint256 maxSupply_,
        uint256 maxPerWallet_,
        address signer_,
        address initialOwner_,
        uint256 targetChainId_, // Added for security fix
        address[] memory payees_,
        uint256[] memory shares_
    ) ERC721A(name_, symbol_) Ownable(initialOwner_) PaymentSplitter(payees_, shares_) {
        require(mintPrice_ > 0, "Mint price must be > 0");
        require(maxSupply_ > 0 && maxSupply_ <= 10000, "Max supply must be 1-10000");
        require(maxPerWallet_ > 0, "Max per wallet must be > 0");
        require(signer_ != address(0), "Signer cannot be zero address");
        require(targetChainId_ > 0, "Chain ID must be > 0");

        mintPrice = mintPrice_;
        maxSupply = maxSupply_;
        maxPerWallet = maxPerWallet_;
        signer = signer_;
        TARGET_CHAIN_ID = targetChainId_;
    }

    // --- Minting Logic ---
    function mint(
        uint256 quantity,
        uint256 expiryTime,
        bytes calldata signature
    ) external payable nonReentrant whenNotPaused {
        require(msg.sender != address(0), "Zero address");
        require(block.chainid == TARGET_CHAIN_ID, "Wrong chain ID");
        require(quantity > 0 && quantity <= 100, "Invalid quantity");
        require(expiryTime > block.timestamp, "Signature expired");
        require(msg.value == mintPrice * quantity, "Incorrect payment");
        require(totalSupply() + quantity <= maxSupply, "Exceeds max supply");
        require(minted[msg.sender] + quantity <= maxPerWallet, "Exceeds per-wallet limit");

        // Verify signature
        bytes32 messageHash = keccak256(
            abi.encodePacked(
                msg.sender,
                quantity,
                expiryTime,
                nonces[msg.sender],
                block.chainid
            )
        );
        bytes32 ethSignedMessageHash = messageHash.toEthSignedMessageHash();
        address recoveredSigner = ethSignedMessageHash.recover(signature);

        require(recoveredSigner == signer, "Invalid signature");

        // Canonical s-value check (prevent signature malleability)
        (bytes32 r, bytes32 s, uint8 v) = splitSignature(signature);
        require(uint256(s) <= 0x7fffffffffffffffffffffffffffffff5d576e7357a4501ddfe92f46681b20a0, "Invalid s");

        // Prevent replay attacks
        bytes32 txHash = keccak256(abi.encodePacked(msg.sender, quantity, expiryTime, nonces[msg.sender]));
        require(!usedHashes[txHash], "Signature already used");
        usedHashes[txHash] = true;

        // Update state
        nonces[msg.sender]++;
        minted[msg.sender] += quantity;

        // Mint NFTs
        _safeMint(msg.sender, quantity);

        emit Minted(msg.sender, quantity);
    }

    // --- Admin Functions ---
    function setSigner(address newSigner) external onlyOwner {
        require(newSigner != address(0), "Invalid signer");
        address oldSigner = signer;
        signer = newSigner;
        emit SignerUpdated(oldSigner, newSigner);
    }

    function setMintPrice(uint256 newPrice) external onlyOwner {
        require(newPrice > 0, "Price must be > 0");
        uint256 oldPrice = mintPrice;
        mintPrice = newPrice;
        emit MintPriceUpdated(oldPrice, newPrice);
    }

    function setMaxSupply(uint256 newMaxSupply) external onlyOwner {
        require(newMaxSupply > 0 && newMaxSupply <= 10000, "Invalid max supply");
        require(newMaxSupply >= totalSupply(), "Cannot reduce below current supply");
        // ⚠️ SECURITY NOTE: This function lacks a timelock.
        // For production, consider using OpenZeppelin's TimelockController.
        uint256 oldSupply = maxSupply;
        maxSupply = newMaxSupply;
        emit MaxSupplyUpdated(oldSupply, newMaxSupply);
    }

    function setMaxPerWallet(uint256 newLimit) external onlyOwner {
        require(newLimit > 0, "Limit must be > 0");
        uint256 oldLimit = maxPerWallet;
        maxPerWallet = newLimit;
        emit MaxPerWalletUpdated(oldLimit, newLimit);
    }

    function pause() external onlyOwner {
        _pause();
    }

    function unpause() external onlyOwner {
        _unpause();
    }

    // --- PaymentSplitter Integration ---
    function releasePayee(address payable account) external {
        release(account);
    }

    // --- Utility Functions ---
    function splitSignature(bytes memory sig)
        internal
        pure
        returns (bytes32 r, bytes32 s, uint8 v)
    {
        require(sig.length == 65, "Invalid signature length");
        assembly {
            r := mload(add(sig, 32))
            s := mload(add(sig, 64))
            v := byte(0, mload(add(sig, 96)))
        }
    }

    function getMintedCount(address account) external view returns (uint256) {
        return minted[account];
    }

    function getNonce(address account) external view returns (uint256) {
        return nonces[account];
    }

    function getRemainingSupply() external view returns (uint256) {
        return maxSupply - totalSupply();
    }

    function getChainId() external view returns (uint256) {
        return TARGET_CHAIN_ID;
    }

    // --- Required Overrides ---
    function _baseURI() internal view override returns (string memory) {
        return "ipfs://";
    }
}
