import { ethers } from "ethers";
import * as fs from "fs";

// Your MetaMask address
const OWNER_ADDRESS = "0x3Cec101153d84b4686BeEA4de0e99e08004A3fa0";

// Testnet RPC URLs
const SEPOLIA_RPC = "https://rpc.sepolia.org";
const AMOY_RPC = "https://rpc-amoy.polygon.technology";

// Contract ABI (simplified for deployment)
const CONTRACT_ABI = [
  "constructor(string name_, string symbol_, uint256 mintPrice_, uint256 maxSupply_, uint256 maxPerWallet_, address signer_, address initialOwner_, uint256 targetChainId_, address[] payees_, uint256[] shares_)",
];

// Contract bytecode (you need to compile the contract first)
// For now, using a placeholder - replace with actual bytecode
const CONTRACT_BYTECODE = "0x"; // Placeholder

async function deployToTestnet(chainName, rpcUrl, chainId) {
  console.log(`\n🚀 Deploying to ${chainName}...`);

  try {
    const provider = new ethers.JsonRpcProvider(rpcUrl);
    
    // You'll need to provide the private key for deployment
    // For testnet, you can use a test private key
    const deployerPrivateKey = process.env.TESTNET_DEPLOYER_KEY;
    
    if (!deployerPrivateKey) {
      console.log(`⚠️  TESTNET_DEPLOYER_KEY not set. Using owner address for reference only.`);
      console.log(`   Owner: ${OWNER_ADDRESS}`);
      console.log(`   Network: ${chainName} (Chain ID: ${chainId})`);
      console.log(`   RPC: ${rpcUrl}`);
      return;
    }

    const signer = new ethers.Wallet(deployerPrivateKey, provider);
    
    console.log(`Deployer: ${signer.address}`);
    console.log(`Owner: ${OWNER_ADDRESS}`);

    // Contract deployment parameters
    const deployParams = {
      name: "MintGrind NFT",
      symbol: "MGND",
      mintPrice: ethers.parseEther("0.01"), // 0.01 ETH/MATIC
      maxSupply: 10000,
      maxPerWallet: 100,
      signer: signer.address, // Signer for whitelist
      initialOwner: OWNER_ADDRESS,
      targetChainId: chainId,
      payees: [OWNER_ADDRESS], // Single payee
      shares: [100], // 100% to owner
    };

    console.log(`\nDeployment Parameters:`);
    console.log(`  Name: ${deployParams.name}`);
    console.log(`  Symbol: ${deployParams.symbol}`);
    console.log(`  Mint Price: ${ethers.formatEther(deployParams.mintPrice)} ${chainName === "Ethereum Sepolia" ? "ETH" : "MATIC"}`);
    console.log(`  Max Supply: ${deployParams.maxSupply}`);
    console.log(`  Max Per Wallet: ${deployParams.maxPerWallet}`);
    console.log(`  Payees: ${deployParams.payees.join(", ")}`);
    console.log(`  Shares: ${deployParams.shares.join(", ")}`);

    console.log(`\n✅ Deployment configuration ready for ${chainName}`);
    console.log(`   To deploy, you need to:`);
    console.log(`   1. Compile the contract: npx hardhat compile`);
    console.log(`   2. Set TESTNET_DEPLOYER_KEY environment variable`);
    console.log(`   3. Run this script again`);

  } catch (error) {
    console.error(`❌ Error deploying to ${chainName}:`, error.message);
  }
}

async function main() {
  console.log("🔗 MintGrind NFT Contract Deployment - Testnet");
  console.log("=".repeat(50));

  await deployToTestnet("Ethereum Sepolia", SEPOLIA_RPC, 11155111);
  await deployToTestnet("Polygon Amoy", AMOY_RPC, 80002);

  console.log("\n" + "=".repeat(50));
  console.log("📝 Deployment Summary:");
  console.log(`   Owner Address: ${OWNER_ADDRESS}`);
  console.log(`   Networks: Ethereum Sepolia, Polygon Amoy`);
  console.log(`   Status: Ready for deployment`);
}

main().catch(console.error);
